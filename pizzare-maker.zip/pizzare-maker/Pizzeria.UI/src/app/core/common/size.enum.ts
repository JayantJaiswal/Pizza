export enum Size {
    Small = 0,
    Medium = 1,
    Large = 2
}