export interface IErrors {
    errors: { [key: string]: string };
}
