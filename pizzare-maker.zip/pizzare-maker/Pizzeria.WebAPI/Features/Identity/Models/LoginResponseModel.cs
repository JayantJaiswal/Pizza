﻿namespace Pizzeria.WebAPI.Features.Identity.Models
{
    public class LoginResponseModel
    {
        public string Token { get; set; }
    }
}
