﻿namespace Pizzeria.WebAPI.Features.Pizzas.Models
{
    public class PizzasDetailsResponseModel : PizzasListingResponseModel
    {
        public int Calories { get; set; }
    }
}
