﻿namespace Pizzeria.WebAPI.Infrastructure.Services.Common
{
    public interface ISingletonService
    {
    }
}
