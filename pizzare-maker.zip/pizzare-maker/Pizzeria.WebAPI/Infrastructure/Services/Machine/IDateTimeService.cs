﻿namespace Pizzeria.WebAPI.Infrastructure.Services.Machine
{
    using System;
    using Common;

    public interface IDateTimeService : IService
    {
        DateTime Now { get; }
    }
}
