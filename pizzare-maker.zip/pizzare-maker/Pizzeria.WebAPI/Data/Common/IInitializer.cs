﻿namespace Pizzeria.WebAPI.Data.Common
{
    public interface IInitializer
    {
        void Initialize();
    }
}